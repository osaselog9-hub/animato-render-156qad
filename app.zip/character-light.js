// Lights the characters like they stand inside the set (pure functions, no DOM, so they are unit tested in Node).
//
// A flat cartoon person pasted onto a lit room looks like a sticker. This gives every character what an object in a real place has:
//   - a lit side that faces the set's light, and a shaded side away from it (soft gradients, clipped to the character's own outline)
//   - a warm or cold highlight in the light's colour, and a little light on the head and shoulders from above
//   - the colour of the room (night is blue, a lamp is warm, a storm is dark) mixed into the character
//   - darkening toward the feet where the body meets the floor (ambient occlusion)
//   - a soft contact shadow under the feet and a longer cast shadow on the floor, away from the light
// Where the light is comes from the scene: `light:{x,y,color}` (the lamp, window, sun or screen the AI drew), else from the mood.
// The shading is drawn with gradients and a mask (no filters), so it plays smoothly and exports exactly as it looks.

export const LIGHT_MARK = 'data-charlight';

/** How each mood lights a person: key = colour of the main light, amb = colour of the room, ambA = how much of it, shade = darkness of the shaded side, keyA = strength of the highlight. */
export const MOOD_LIGHT = Object.freeze({
  night: { key: '#8fa8ff', amb: '#0a1233', ambA: 0.26, shade: 0.46, keyA: 0.34 },
  cold: { key: '#a9c4ff', amb: '#0c2144', ambA: 0.16, shade: 0.38, keyA: 0.3 },
  tense: { key: '#9fb4e8', amb: '#0b1a33', ambA: 0.18, shade: 0.42, keyA: 0.28 },
  rain: { key: '#9db4d8', amb: '#0d192b', ambA: 0.2, shade: 0.44, keyA: 0.26 },
  storm: { key: '#b8c7ff', amb: '#0a1220', ambA: 0.24, shade: 0.5, keyA: 0.32 },
  space: { key: '#7aa0ff', amb: '#05091a', ambA: 0.2, shade: 0.5, keyA: 0.32 },
  dark: { key: '#ffffff', amb: '#000000', ambA: 0.3, shade: 0.56, keyA: 0.24 },
  warm: { key: '#ffc079', amb: '#ff9d42', ambA: 0.1, shade: 0.3, keyA: 0.36 },
  hype: { key: '#ffe27a', amb: '#ffd54a', ambA: 0.06, shade: 0.26, keyA: 0.34 },
  city: { key: '#ffd9a0', amb: '#1c2541', ambA: 0.08, shade: 0.32, keyA: 0.3 },
  calm: { key: '#fff3d6', amb: '#ffe9c4', ambA: 0.04, shade: 0.28, keyA: 0.3 },
  default: { key: '#fff1d0', amb: '#000000', ambA: 0, shade: 0.3, keyA: 0.28 },
});

const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const num = (v, d) => (v !== null && v !== '' && v !== true && v !== false && Number.isFinite(+v) ? +v : d);
const HEX = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i;
const f1 = (n) => (Math.round(n * 10) / 10).toString();
const f2 = (n) => (Math.round(n * 100) / 100).toString();

/** The scene's light as plain numbers: { x, y, key, amb, ambA, shade, keyA, off }. */
export function sceneLight(sc) {
  const s = sc || {};
  const mood = String(s.mood || s.m || '').toLowerCase().trim();
  const base = MOOD_LIGHT[mood] || MOOD_LIGHT.default;
  const out = { x: 480, y: 140, key: base.key, amb: base.amb, ambA: base.ambA, shade: base.shade, keyA: base.keyA, off: false };
  const L = s.light;
  if (L === false || s.lighting === false) { out.off = true; return out; }
  if (typeof L === 'string') {
    const w = L.toLowerCase().trim();
    if (HEX.test(w)) out.key = w;
    else if (w === 'left') { out.x = 200; out.y = 300; }
    else if (w === 'right') { out.x = 1400; out.y = 300; }
    else if (w === 'top' || w === 'above') { out.x = 800; out.y = 40; }
    else if (w === 'front') { out.x = 800; out.y = 450; }
    else if (w === 'back') { out.x = 800; out.y = 450; out.shade = Math.min(0.62, out.shade + 0.16); out.keyA *= 0.6; }
  } else if (L && typeof L === 'object') {
    out.x = clamp(num(L.x, out.x), -400, 2000);
    out.y = clamp(num(L.y, out.y), -200, 1100);
    if (typeof L.color === 'string' && HEX.test(L.color.trim())) out.key = L.color.trim();
    const st = num(L.strength, NaN);
    if (Number.isFinite(st)) { const k = clamp(st, 0, 2); out.keyA = clamp(out.keyA * k, 0, 0.7); out.shade = clamp(out.shade * (0.6 + 0.4 * k), 0, 0.7); }
  }
  return out;
}

/**
 * Lights one character.
 * @param {object} o
 * @param {object} o.scene   the scene (mood, light)
 * @param {number} o.x       where the character stands on screen (scene units)
 * @param {boolean} o.flip   the character is mirrored
 * @param {string} o.id      a unique id prefix for this character in this frame
 * @param {string} o.svg     the character's drawing (centred on x=0, feet at y=880)
 * @param {number} o.height  how tall that drawing is at scale 1 (its head top is at y = 880 - height)
 * @returns {{shadow:string, body:string}}  `shadow` is drawn first (on the floor), `body` is the lit character.
 */
export function lightCharacter(o = {}) {
  const { scene, x = 800, flip = false, id = 'lc', svg = '', height = 640, lite = false } = o;
  const L = sceneLight(scene);
  const art = String(svg || '');
  if (L.off || !art.trim()) return { shadow: '', body: art };
  // which way does the light fall on this person, as seen on screen? -1 = from the left, +1 = from the right, 0 = straight on
  const dx = clamp((L.x - num(x, 800)) / 520, -1, 1);
  const front = 1 - Math.abs(dx);                                   // 1 when the light is right in front or above
  const top = clamp(1 - L.y / 700, 0.25, 1);                        // a high light shines on the head and shoulders more
  const sd = flip ? -dx : dx;                                       // the drawing is mirrored when flipped, so mirror the light too
  const hh = clamp(num(height, 640), 300, 900), W = 300, y0 = Math.max(0, Math.round(880 - hh - 14)), y1 = 910, H = y1 - y0, TOPH = Math.round(hh * 0.34);
  const shade = clamp(L.shade * 1.45, 0, 0.72), keyA = clamp(L.keyA * 1.5, 0, 0.66);
  const as = Math.abs(sd);
  // rough body geometry (every style stands feet-on-floor at y=880): the head is the top fifth, the body is about a fifth of the height wide
  const HEADS = { 722: [0.34, 0.2], 700: [0.2, 0.15], 650: [0.2, 0.14], 640: [0.2, 0.14], 604: [0.09, 0.075] };   // [centre of the head below the top, radius] as parts of the height, by drawing style
  const hd = (o && o.head) || HEADS[Math.round(hh)] || HEADS[722];
  const top0 = 880 - hh, Rh = hh * hd[1], hy = top0 + hh * hd[0], chinY = hy + Rh * 0.95, bw = Math.max(hh * 0.15, 90);
  const chinUp0 = 880 - (hy + Rh * 0.95), hw0 = Math.max(Rh * 0.55, hh * 0.05), legUp0 = chinUp0 * 0.38;
  const hiA = keyA * (0.45 + 0.55 * as);
  const edge = sd >= 0 ? 'r' : 'l';                                  // which edge is lit
  const gid = (n) => `${id}${n}`;
  // the form shadow: a soft terminator across the body, dark on the side away from the light (front light: both edges roll off a little)
  const aS = shade * (0.66 + 0.4 * as), TN = '#4a4870';           // the shade is a cool dark tint; it is MULTIPLIED, so ink lines stay black and sharp
  const stops = as < 0.12
    ? `<stop offset="0" stop-color="${TN}" stop-opacity="${f2(aS * 0.7)}"/><stop offset=".13" stop-color="${TN}" stop-opacity="${f2(aS * 0.22)}"/><stop offset=".25" stop-color="${TN}" stop-opacity="0"/><stop offset=".75" stop-color="${TN}" stop-opacity="0"/><stop offset=".87" stop-color="${TN}" stop-opacity="${f2(aS * 0.22)}"/><stop offset="1" stop-color="${TN}" stop-opacity="${f2(aS * 0.7)}"/>`
    : (sd > 0
      ? `<stop offset="0" stop-color="${TN}" stop-opacity="${f2(aS)}"/><stop offset=".34" stop-color="${TN}" stop-opacity="${f2(aS * 0.92)}"/><stop offset=".47" stop-color="${TN}" stop-opacity="${f2(aS * 0.34)}"/><stop offset=".58" stop-color="${TN}" stop-opacity="${f2(aS * 0.1)}"/><stop offset="1" stop-color="${TN}" stop-opacity="0"/>`
      : `<stop offset="0" stop-color="${TN}" stop-opacity="0"/><stop offset=".42" stop-color="${TN}" stop-opacity="${f2(aS * 0.1)}"/><stop offset=".53" stop-color="${TN}" stop-opacity="${f2(aS * 0.34)}"/><stop offset=".66" stop-color="${TN}" stop-opacity="${f2(aS * 0.92)}"/><stop offset="1" stop-color="${TN}" stop-opacity="${f2(aS)}"/>`);
  const hx = sd * Rh * 0.5, hxs = -sd * Rh * 0.2, ballK = 0.5 + 0.5 * as;
  const defs =
    `<linearGradient id="${gid('s')}" gradientUnits="userSpaceOnUse" x1="${f1(-bw)}" y1="0" x2="${f1(bw)}" y2="0">${stops}</linearGradient>` +
    `<linearGradient id="${gid('h')}" gradientUnits="userSpaceOnUse" x1="${edge === 'r' ? W : -W}" y1="0" x2="${edge === 'r' ? W * 0.05 : -W * 0.05}" y2="0">` +
    `<stop offset="0" stop-color="${L.key}" stop-opacity="${f2(Math.min(1, hiA * 2.2))}"/><stop offset=".07" stop-color="${L.key}" stop-opacity="${f2(Math.min(1, hiA * 1.5))}"/><stop offset=".2" stop-color="${L.key}" stop-opacity="${f2(hiA * 0.5)}"/><stop offset=".45" stop-color="${L.key}" stop-opacity="${f2(hiA * 0.14)}"/><stop offset="1" stop-color="${L.key}" stop-opacity="0"/></linearGradient>` +
    `<linearGradient id="${gid('t')}" gradientUnits="userSpaceOnUse" x1="0" y1="${y0}" x2="0" y2="${y0 + TOPH}">` +
    `<stop offset="0" stop-color="${L.key}" stop-opacity="${f2(0.2 * top * (0.5 + 0.5 * front) * (keyA / 0.3))}"/><stop offset="1" stop-color="${L.key}" stop-opacity="0"/></linearGradient>` +
    `<linearGradient id="${gid('f')}" gradientUnits="userSpaceOnUse" x1="0" y1="${y1 - 260}" x2="0" y2="${y1}">` +
    `<stop offset="0" stop-color="${TN}" stop-opacity="0"/><stop offset="1" stop-color="${TN}" stop-opacity="${f2(0.3 + shade * 0.3)}"/></linearGradient>` +
    // the head is a ball: lit toward the light, a core shadow on the far side
    `<radialGradient id="${gid('b')}" gradientUnits="userSpaceOnUse" cx="${f1(hx)}" cy="${f1(hy - Rh * 0.18)}" r="${f1(Rh * 1.12)}">` +
    `<stop offset="0" stop-color="${L.key}" stop-opacity="${f2(hiA * 0.55)}"/><stop offset=".4" stop-color="${L.key}" stop-opacity="${f2(hiA * 0.12)}"/><stop offset=".74" stop-color="${TN}" stop-opacity="${f2(shade * ballK * 0.16)}"/><stop offset=".9" stop-color="${TN}" stop-opacity="${f2(shade * ballK * 0.7)}"/><stop offset="1" stop-color="${TN}" stop-opacity="0"/></radialGradient>` +
    // the shadow of the chin on the neck and chest, and of the head on the shoulder away from the light
    `<radialGradient id="${gid('k')}" gradientUnits="userSpaceOnUse" cx="${f1(hxs)}" cy="${f1(chinY + Rh * 0.12)}" r="${f1(Rh * 0.95)}" gradientTransform="translate(${f1(hxs)} ${f1(chinY + Rh * 0.12)}) scale(1 .62) translate(${f1(-hxs)} ${f1(-(chinY + Rh * 0.12))})">` +
    `<stop offset="0" stop-color="${TN}" stop-opacity="${f2(0.4 + shade * 0.5)}"/><stop offset=".62" stop-color="${TN}" stop-opacity="${f2(0.2 + shade * 0.2)}"/><stop offset="1" stop-color="${TN}" stop-opacity="0"/></radialGradient>` +
    // where the clothes meet: a soft occlusion band at the hem / waist, and a highlight on the shoulder that faces the light
    `<radialGradient id="${gid('hm')}"><stop offset="0" stop-color="${TN}" stop-opacity="${f2(0.2 + shade * 0.3)}"/><stop offset="1" stop-color="#05081a" stop-opacity="0"/></radialGradient>` +
    `<radialGradient id="${gid('sh')}"><stop offset="0" stop-color="${L.key}" stop-opacity="${f2(Math.min(0.5, hiA * 0.55))}"/><stop offset="1" stop-color="${L.key}" stop-opacity="0"/></radialGradient>` +
    `<mask id="${gid('m')}" maskUnits="userSpaceOnUse" x="${-W}" y="${y0}" width="${2 * W}" height="${H}" style="mask-type:alpha"><use href="#${gid('g')}"/></mask>`;
  const MB = (m) => `style="mix-blend-mode:${m}"`;
  const R = (fill, h = H, y = y0) => `<rect x="${-W}" y="${y}" width="${2 * W}" height="${h}" fill="${fill}"/>`;
  const light =
    `<g ${LIGHT_MARK}="1" mask="url(#${gid('m')})" pointer-events="none">` +
    `<g ${MB('multiply')}>` +
    (L.ambA > 0 ? `<rect x="${-W}" y="${y0}" width="${2 * W}" height="${H}" fill="${L.amb}" opacity="${f2(Math.min(0.9, L.ambA * 1.6))}"/>` : '') +
    R(`url(#${gid('s')})`) +
    `<ellipse cx="0" cy="${f1(hy)}" rx="${f1(Rh * 1.06)}" ry="${f1(Rh * 1.12)}" fill="url(#${gid('b')})"/>` +
    `<ellipse cx="${f1(hxs)}" cy="${f1(chinY + Rh * 0.12)}" rx="${f1(Rh * 0.95)}" ry="${f1(Rh * 0.6)}" fill="url(#${gid('k')})"/>` +
    `<ellipse cx="0" cy="${f1(880 - legUp0)}" rx="${f1(hw0 * 1.6)}" ry="${f1(hh * 0.04)}" fill="url(#${gid('hm')})"/>` +
    R(`url(#${gid('f')})`, 260, y1 - 260) + `</g>` +
    `<g ${MB('soft-light')}>` + R(`url(#${gid('h')})`) + R(`url(#${gid('h')})`) + R(`url(#${gid('t')})`, TOPH) +
    `<ellipse cx="${f1(sd * hw0 * 0.75)}" cy="${f1(880 - chinUp0 + hh * 0.05)}" rx="${f1(hw0 * 0.9)}" ry="${f1(hh * 0.055)}" fill="url(#${gid('sh')})"/></g></g>`;
  // the character is drawn ONCE, in place; the mask reads the same group. (Drawing it again with <use> doubled the work of every frame.)
  // lite = a live preview on a phone that cannot keep up: no mask, so the lit-side shading is left out and only the floor shadow stays.
  // Exports never use lite, so the finished video always has the full lighting.
  const body = lite ? art : `<defs>${defs}</defs><g id="${gid('g')}" shape-rendering="geometricPrecision">${art}</g>${light}`;
  // the shadow on the floor: a tight one right under the feet, and the person's own shape thrown away from the light (a stand-in drawn from simple
  // shapes, softened by three widths of the same shape, so it costs almost nothing)
  const lenK = clamp(1.15 - L.y / 800, 0.4, 1) * as, tx = -Math.sign(sd || 1) * 0.85 * lenK, ty = -0.2 * (0.5 + 0.5 * as);
  const P = (px, up) => `${f1(px + tx * up)},${f1(884 + ty * up)}`;
  const chinUp = 880 - (hy + Rh * 0.95), hUp = 880 - hy, hw = Math.max(Rh * 0.55, hh * 0.05), legUp = chinUp * 0.38;
  const legs = [-1, 1].map((k) => `M${P(k * hw * 0.25, 0)} L${P(k * hw * 1.0, 0)} L${P(k * hw * 0.85, legUp)} L${P(k * hw * 0.1, legUp)}Z`).join('');
  const torso = `M${P(-hw * 1.25, legUp)} L${P(hw * 1.25, legUp)} L${P(hw * 1.1, chinUp)} L${P(-hw * 1.1, chinUp)}Z`;
  const headP = Array.from({ length: 16 }, (_, i) => { const a = (i / 16) * Math.PI * 2; return `${i ? 'L' : 'M'}${P(Math.cos(a) * Rh * 0.98, hUp + Math.sin(a) * Rh * 1.02)}`; }).join('') + 'Z';
  const sil = legs + torso + headP;
  // the REAL cast shadow: the character's own drawing (through the same mask), laid flat on the floor along the light, so a swinging arm, a stride or a
  // turned head moves the shadow too. It fades with height (sharp at the feet, softer higher up) and a wider, fainter copy gives the soft edge. No filters.
  const lay = (k, op, grow) => {
    const tx2 = tx * k, ty2 = ty * k, m = `matrix(${f2(grow)} 0 ${f2(-tx2)} ${f2(-ty2)} ${f2(tx2 * 880)} ${f2(884 + ty2 * 880)})`;
    return `<g transform="${m}"><rect x="${-W}" y="${y0}" width="${2 * W}" height="${H}" fill="url(#${gid('cs')})" mask="url(#${gid('m')})" opacity="${op}"/></g>`;
  };
  const realCast = lite || as < 0.1 ? '' :
    `<defs><linearGradient id="${gid('cs')}" gradientUnits="userSpaceOnUse" x1="0" y1="880" x2="0" y2="${f1(880 - hh)}"><stop offset="0" stop-color="#000" stop-opacity="1"/><stop offset=".55" stop-color="#000" stop-opacity=".72"/><stop offset="1" stop-color="#000" stop-opacity=".4"/></linearGradient></defs>` +
    lay(1.1, f2(0.1 + 0.04 * as), 1.06) + lay(1, f2(0.26 + 0.1 * as), 1);
  const cast = (!lite || as < 0.1) ? '' :
    `<g fill="#000" stroke="#000" stroke-linejoin="round" stroke-width="0" opacity="${f2(0.3 + 0.14 * as)}"><path d="${sil}"/></g>` +
    `<g fill="#000" stroke="#000" stroke-linejoin="round" stroke-width="16" opacity="${f2(0.15 + 0.06 * as)}"><path d="${sil}"/></g>` +
    `<g fill="#000" stroke="#000" stroke-linejoin="round" stroke-width="34" opacity="${f2(0.08 + 0.04 * as)}"><path d="${sil}"/></g>`;
  const shadow =
    `<g ${LIGHT_MARK}="floor" pointer-events="none">${cast}${realCast}<defs><radialGradient id="${gid('c2')}" cx=".5" cy=".5" r=".5"><stop offset="0" stop-color="#000" stop-opacity="${f2(0.36 + 0.14 * as)}"/><stop offset=".7" stop-color="#000" stop-opacity="0.12"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient></defs>` +
    `<ellipse cx="${f1(-sd * 26)}" cy="884" rx="${f1(86 + 14 * front)}" ry="${f1(17 + 3 * as)}" fill="url(#${gid('c2')})"/>` +
    `<ellipse cx="0" cy="882" rx="${f1(70 + 10 * front)}" ry="12" fill="url(#${gid('c2')})"/></g>`;
  return { shadow, body };
}
